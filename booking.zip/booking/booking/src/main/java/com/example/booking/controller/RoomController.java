package com.example.booking.controller;

import com.example.booking.entity.Room;
import com.example.booking.service.IRoomService;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.booking.repository.RoomRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/api/rooms")
public class RoomController {

    @Autowired
    private IRoomService roomService;
    @Autowired
    private RoomRepository roomRepository;

    @GetMapping("/room/{id}")
    public String viewRoomDetail(@PathVariable Long id, Model model) {
        Room room = roomService.getRoomById(id);
        if (room == null) {
            return "error/404"; // tạo trang nếu muốn
        }
        model.addAttribute("room", room);
        return "room/room_detail";
    }

    @GetMapping("/{id}")
    public ResponseEntity<Room> getRoomById(@PathVariable Long id) {
        return roomRepository.findById(id)
                .map(room -> ResponseEntity.ok(room))
                .orElse(ResponseEntity.notFound().build());
    }


}
