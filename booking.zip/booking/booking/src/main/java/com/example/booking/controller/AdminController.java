package com.example.booking.controller;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.booking.entity.Booking;
import com.example.booking.entity.Payment;
import com.example.booking.entity.Role;
import com.example.booking.entity.Room;
import com.example.booking.entity.User;
import com.example.booking.service.*;
import com.example.booking.repository.*;

@Controller
public class AdminController {

    @Autowired
    private final RoomService roomService;
    @Autowired
    private final IUserService  userService;
    @Autowired
    private PaymentService paymentService;  
    @Autowired
    private final RoomRepository roomRepository;
    @Autowired
    private final UserRepository userRepository;
    @Autowired
    private BookingService bookingService;

    public AdminController(RoomService roomService, 
            IUserService  userService, 
            RoomRepository roomRepository,
            UserRepository userRepository) {
        this.roomService = roomService;
        this.userService = userService;
        this.roomRepository = roomRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/admin")
    public String index() {
        return "admin/admin_dashboard";
    }

    @GetMapping("/admin/rooms")
    public String room(Model model) {
        model.addAttribute("listRooms", roomService.findAll());
        return "admin/room/rooms";
    }

    @GetMapping("/admin/rooms/view/{id}")
    public String viewRoom(@PathVariable Long id, Model model) {
        Room room = roomRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Room not found"));
        model.addAttribute("room", room);
        return "admin/room/view_room";
    }

    @GetMapping("/admin/rooms/edit/{id}")
    public String editRoom(@PathVariable Long id, Model model) {
        Room room = roomRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Room not found"));
        model.addAttribute("room", room);
        return "admin/room/edit_room";
    }

    @GetMapping("/admin/rooms/new")
    public String newRoom(Model model) {;
        model.addAttribute("room", new Room());
        return "admin/room/create_room";
    }

    @PostMapping("/admin/rooms/new")
    public String saveRoom(@ModelAttribute("room") Room room) {
        room.setStatus(Room.RoomStatus.AVAILABLE); // mặc định trạng thái
        roomRepository.save(room);
        return "redirect:/admin/rooms";
    }

    @GetMapping("/admin/users")
    public String user(Model model) {
        List<User> users = userService.findAll();
        if (users == null) {
            users = new ArrayList<>();
        }
        model.addAttribute("listUsers", users);
        return "admin/user/users";
    }

    @GetMapping("/admin/users/view/{id}")
    public String viewUser(@PathVariable Long id, Model model) {
        User user = userRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("User not found"));
        model.addAttribute("user", user);
        return "admin/user/view_user";
    }

    @GetMapping("/admin/users/edit/{id}")
    public String editUser(@PathVariable Long id, Model model) {
        User user = userRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("User not found"));
        model.addAttribute("user", user);
        return "admin/user/edit_user";
    }

    @PostMapping("/admin/users/edit/{id}")
    public String updateUser(@PathVariable Long id, @ModelAttribute("user") User user) {
        User existingUser = userService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        existingUser.setFullName(user.getFullName());
        existingUser.setEmail(user.getEmail());
        existingUser.setPhone(user.getPhone());

        // Convert the string to Role enum if necessary
        String roleName = user.getRole().toString(); // Assuming user.getRole() returns a Role enum
        Role role = Role.valueOf(roleName); // This will safely convert the string to Role enum

        existingUser.setRole(role);

        userService.save(existingUser);
        return "redirect:/admin/users";
    }

    @GetMapping("/admin/users/new")
    public String newUser(Model model) {
        User user = new User();
        user.setRole(Role.valueOf("USER")); // set mặc định là USER để tránh null
        model.addAttribute("user", user);
        return "admin/user/create_user";
    }


    @PostMapping("/admin/users/new")
    public String saveUser(@ModelAttribute("user") User user) {
        user.setRole(Role.valueOf("USER"));
        userRepository.save(user);
        return "redirect:/admin/user";
    }

    @GetMapping("/admin/booking")
    public String bookingList(Model model) {
        model.addAttribute("bookings", bookingService.getAllBookings());
        return "admin/booking/bookings";
    }

    @GetMapping("/admin/bookings/view/{id}")
    public String viewBooking(@PathVariable Long id, Model model) {
        Booking booking = bookingService.getBookingById(id).orElseThrow();
        model.addAttribute("booking", booking);
        return "admin/booking/view_booking";
    }

    @GetMapping("/admin/bookings/edit/{id}")
    public String editBooking(@PathVariable Long id, Model model) {
        Booking booking = bookingService.getBookingById(id).orElseThrow();
        model.addAttribute("booking", booking);
        model.addAttribute("users", userService.findAll());
        model.addAttribute("rooms", roomService.findAll());
        return "admin/booking/edit_booking"; // tên khớp template
    }


    @PostMapping("/admin/bookings/update/{id}")
    public String updateBooking(@PathVariable Long id, @ModelAttribute Booking booking) {
        bookingService.updateBooking(id, booking);
        return "redirect:/admin/booking";
    }

    @GetMapping("/admin/bookings/new")
    public String showBookingForm(Model model) {
        model.addAttribute("booking", new Booking());
        model.addAttribute("users", userService.findAll());
        model.addAttribute("rooms", roomService.findAll());
        return "admin/booking/create_booking";
    }

    @PostMapping("/admin/bookings/save")
    public String saveBooking(@ModelAttribute Booking booking, Model model) {
        boolean isOverlapping = bookingService.isOverlappingBooking(
            booking.getRoom().getId(),
            booking.getCheckIn(),
            booking.getCheckOut()
        );

        if (isOverlapping) {
            model.addAttribute("error", "⚠️ Khung giờ đã có người đặt phòng này.");
            model.addAttribute("booking", booking);
            model.addAttribute("users", userService.findAll());
            model.addAttribute("rooms", roomService.findAll());
            return "admin/booking/create_booking";
        }

        bookingService.createBooking(booking);
        return "redirect:/admin/booking";
    }

    @GetMapping("/admin/payment")
    public String payments(Model model) {
        model.addAttribute("payments", paymentService.getAllPayments());
        return "admin/payment/payments";
    }

    @GetMapping("/admin/payment/view/{id}")
    public String viewPayment(@PathVariable Long id, Model model) {
        Payment payment = paymentService.getPaymentById(id).orElseThrow();
        model.addAttribute("payment", payment);
        return "admin/payment/view_payment";
    }

    @GetMapping("/admin/payment/new")
    public String createPaymentForm(Model model) {
         Payment payment = new Payment();
        payment.setAmount(0.0); // ✅ tránh null để th:field không lỗi
        payment.setPaymentDate(LocalDateTime.now()); // có thể đặt mặc định luôn
        model.addAttribute("payment", payment);
        model.addAttribute("bookings", bookingService.getAllBookings());
        return "admin/payment/create_payment";
    }

    @PostMapping("/admin/payments/save")
    public String savePayment(@ModelAttribute Payment payment) {
        // Lấy booking từ DB dựa trên booking.id được chọn từ form
        Booking booking = bookingService.getBookingById(payment.getBooking().getId()).orElseThrow();

        // Gán lại đối tượng đầy đủ
        payment.setBooking(booking);

        paymentService.createPayment(payment);
        return "redirect:/admin/payments";
    }

    @GetMapping("/admin/payment/edit/{id}")
    public String editPayment(@PathVariable Long id, Model model) {
        Payment payment = paymentService.getPaymentById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy payment với id = " + id));

        List<Booking> bookings = bookingService.getAllBookings();

        model.addAttribute("payment", payment);
        model.addAttribute("bookings", bookings);
        return "admin/payment/edit_payment"; // Không có .html ở đây
    }
    

    @PostMapping("/admin/payment/update/{id}")
    public String updatePayment(@PathVariable Long id, @ModelAttribute Payment updatedPayment) {
        Payment existing = paymentService.getPaymentById(id).orElseThrow();

        existing.setAmount(updatedPayment.getAmount());
        existing.setBooking(updatedPayment.getBooking());
        existing.setMethod(updatedPayment.getMethod());
        existing.setStatus(updatedPayment.getStatus());
        existing.setPaymentDate(updatedPayment.getPaymentDate());

        paymentService.createPayment(existing); // dùng lại save
        return "redirect:/admin/payment";
    }

    @GetMapping("/admin/payment/delete/{id}")
    public String deletePayment(@PathVariable Long id) {
        paymentService.deletePayment(id);
        return "redirect:/admin/payment";
    }

    @GetMapping("/admin/profile")
    public String adminProfile(Model model, Principal principal) {
        // Lấy user đang đăng nhập từ username
        String username = principal.getName();
        User admin = userService.getUserByUsername(username);
        model.addAttribute("admin", admin);
        return "admin/profile";
    }


}
