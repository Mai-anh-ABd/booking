package com.example.booking.repository;

import com.example.booking.entity.Booking;
import com.example.booking.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    // Bạn có thể thêm: List<Payment> findByBooking_Id(Long bookingId);
    Payment findByBooking(Booking booking);
}
