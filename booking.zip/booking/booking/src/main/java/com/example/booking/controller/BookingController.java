package com.example.booking.controller;

import com.example.booking.entity.Booking;
import com.example.booking.entity.Payment;
import com.example.booking.entity.Room;
import com.example.booking.entity.User;
import com.example.booking.service.BookingService;
import com.example.booking.service.IBookingService;
import com.example.booking.service.IRoomService;
import com.example.booking.service.IUserService;
import com.example.booking.service.PaymentService;
import com.example.booking.service.RoomService;
import com.example.booking.service.UserService;
import com.example.booking.service.IPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;

@Controller
public class BookingController {

    private final BookingService bookingService;
    private final RoomService roomService;
    private final UserService userService;
    private final PaymentService paymentService;

    @Autowired
    public BookingController(BookingService bookingService,
                             RoomService roomService,
                             UserService userService,
                             PaymentService paymentService) {
        this.bookingService = bookingService;
        this.roomService = roomService;
        this.userService = userService;
        this.paymentService = paymentService;
    }

    @GetMapping("/user/booking/new")
    public String showBookingForm(@RequestParam("roomId") Long roomId, Model model, Principal principal) {
        Room room = roomService.getRoomById(roomId);
        if (room == null) {
            return "redirect:/home";
        }

        Booking booking = new Booking();
        booking.setRoom(room);
        booking.setCheckIn(LocalDateTime.now());
        booking.setCheckOut(LocalDateTime.now().plusDays(1));
        booking.setStatus("BOOKED");

        String username = principal.getName();
        User currentUser = userService.findByUsername(username).orElse(null);
        booking.setUser(currentUser);

        model.addAttribute("booking", booking);
        model.addAttribute("room", room);
        return "booking/booking_form";
    }


    @PostMapping("/user/booking/save")
    public String saveBooking(@ModelAttribute Booking booking) {
        Booking savedBooking = bookingService.save(booking);

        Payment payment = new Payment();
        payment.setBooking(savedBooking);

        if (savedBooking.getRoom() != null && savedBooking.getRoom().getPrice() != null) {
            payment.setAmount(savedBooking.getRoom().getPrice());
            payment.setPaymentDate(LocalDateTime.now());
            payment.setStatus("PENDING");
        } else {
            payment.setAmount(0.0);
            payment.setStatus("UNPAID");
        }

        paymentService.createPayment(payment);

        return "redirect:/user/booking";
    }




    @GetMapping("/user/booking")
    public String viewUserBookings(Model model, Principal principal) {
        String username = principal.getName();
        User user = userService.findByUsername(username).orElse(null);

        if (user != null) {
            List<Booking> bookings = bookingService.findByUsername(username);

            // Gán payment vào từng booking
            for (Booking b : bookings) {
                Payment p = paymentService.findByBooking(b);
                b.setPayment(p);
            }

            model.addAttribute("bookings", bookings);
        }

        return "user/user_booking";
    }


} 
