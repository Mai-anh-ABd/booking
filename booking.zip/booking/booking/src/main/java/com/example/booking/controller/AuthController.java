package com.example.booking.controller;

import com.example.booking.entity.Role;
import com.example.booking.entity.User;
import com.example.booking.service.UserService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public AuthController(UserService userService, PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/login")
        public String loginPage() {
            return "login";  // trỏ về login.html
        }

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new User()); // Đưa object rỗng vào form
        return "register"; // Trả về register.html
    }

    @PostMapping("/register")
    public String processRegister(@ModelAttribute("user") User user, Model model) {
        if (!user.getPassword().equals(user.getConfirmPassword())) {
            model.addAttribute("error", "Mật khẩu không khớp");
            return "register";
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole(Role.valueOf("USER")); // hoặc Role.valueOf("ADMIN") nếu cần gán quyền cao hơn
        userService.save(user);

        return "redirect:/login?register_success";
    }

    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {
        return "forgot_password"; 
    }

    @PostMapping("/forgot-password")
    public String processForgotPassword(@RequestParam String username,
                                        @RequestParam String newPassword,
                                        Model model) {
        Optional<User> optionalUser = userService.findByUsername(username);
        if (optionalUser.isEmpty()) {
            model.addAttribute("error", "Không tìm thấy người dùng với tên đăng nhập này.");
            return "auth/forgot_password";
        }

        User user = optionalUser.get();
        user.setPassword(newPassword);
        userService.save(user);

        model.addAttribute("success", "Mật khẩu đã được cập nhật thành công!");
        return "auth/forgot_password";
    }
}
