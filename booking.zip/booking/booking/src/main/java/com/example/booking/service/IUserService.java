package com.example.booking.service;
import com.example.booking.entity.User;

import java.util.List;
import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetails;

public interface IUserService {
    List<User> findAll();
    boolean existsByUsername(String username);
    Optional<User> findById(Long id);
    UserDetails loadUserByUsername(String username);
    void save(User user);
    User getUserByUsername(String username);
    Optional<User> findByUsername(String username);
}