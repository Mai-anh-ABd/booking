package com.example.booking.service;

import com.example.booking.entity.Room;

import java.util.List;

public interface RoomService {
    List<Room> findAll();
    Room getRoomById(Long id);
}
