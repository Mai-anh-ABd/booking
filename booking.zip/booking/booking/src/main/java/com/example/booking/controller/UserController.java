package com.example.booking.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.booking.entity.Booking;
import com.example.booking.entity.Payment;
import com.example.booking.entity.Room;
import com.example.booking.entity.User;
import com.example.booking.service.IUserService;
import com.example.booking.service.RoomService;

@Controller
public class UserController {

    private final RoomService roomService;
    private final IUserService userService;

    public UserController(RoomService roomService, IUserService userService) {
        this.roomService = roomService;
        this.userService = userService; 
    }


    @GetMapping("/home")
    public String userHome(Model model) {
        model.addAttribute("listRooms", roomService.findAll());
        return "user/home";
    }

    @GetMapping("/user/addToCart")
    public String userAddToCart(@RequestParam("roomId") Long roomId, HttpSession session, RedirectAttributes redirectAttributes) {
        Room room = roomService.getRoomById(roomId);
        if (room == null) {
            redirectAttributes.addFlashAttribute("error", "Phòng không tồn tại.");
            return "redirect:/user/home";
        }

        List<Room> cart = (List<Room>) session.getAttribute("cart");
        if (cart == null) {
            cart = new ArrayList<>();
        }

        // Check if already added
        boolean alreadyInCart = cart.stream().anyMatch(r -> r.getId().equals(roomId));
        if (!alreadyInCart) {
            cart.add(room);
            session.setAttribute("cart", cart);
            redirectAttributes.addFlashAttribute("success", "Đã thêm vào giỏ hàng.");
        } else {
            redirectAttributes.addFlashAttribute("info", "Phòng đã có trong giỏ hàng.");
        }

        return "redirect:/user/home";
    }


    @GetMapping("/user/profile")
    public String userProfile(Model model, Principal principal) {
        String username = principal.getName();
        Optional<User> userOptional = userService.findByUsername(username);

        if (userOptional.isPresent()) {
            model.addAttribute("user", userOptional.get());
            return "user/profile";
        }

        // Trường hợp không tìm thấy user
        return "redirect:/login";
    }

    @GetMapping("/user/profile/edit")
    public String showEditProfileForm(Model model, Principal principal) {
        String username = principal.getName();
        User user = userService.findByUsername(username).orElse(null);

        if (user == null) {
            return "redirect:/login";
        }

        model.addAttribute("user", user);
        return "user/edit_profile";
    }

}