package com.example.booking.controller;

import com.example.booking.entity.Room;
import com.example.booking.service.RoomService;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {

    private final RoomService roomService;

    public MainController(RoomService roomService) {
        this.roomService = roomService;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("listRooms", roomService.findAll());
        return "index";
    }

    @GetMapping("/test-img")
    public String testImage() {
        return "test_static";
    }

    @GetMapping("/search")
    public String searchRooms(@RequestParam(required = false) String keyword,
                            @RequestParam(required = false) Integer capacity,
                            @RequestParam(required = false) Integer area,
                            Model model) {
        List<Room> allRooms = roomService.findAll();

        List<Room> filteredRooms = allRooms.stream()
            .filter(room -> {
                boolean match = true;
                if (keyword != null && !keyword.isBlank()) {
                    String kw = keyword.toLowerCase();
                    match &= room.getRoomNumber().toLowerCase().contains(kw) ||
                            (room.getDescription() != null && room.getDescription().toLowerCase().contains(kw));
                }
                if (capacity != null) {
                    match &= room.getCapacity() != null && room.getCapacity() >= capacity;
                }
                if (area != null) {
                    match &= room.getArea() != null && room.getArea() >= area;
                }
                return match;
            })
            .toList();

        model.addAttribute("listRooms", filteredRooms);
        return "index";
    }

}
