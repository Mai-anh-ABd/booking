package com.example.booking.service;

import com.example.booking.entity.Booking;
import com.example.booking.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class IBookingService implements BookingService {

    private final BookingRepository bookingRepository;

    @Autowired
    public IBookingService(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    @Override
    public Booking createBooking(Booking booking) {
        return bookingRepository.save(booking);
    }

    @Override
    public Booking updateBooking(Long id, Booking booking) {
        return bookingRepository.findById(id)
                .map(existing -> {
                    existing.setCheckIn(booking.getCheckIn());
                    existing.setCheckOut(booking.getCheckOut());
                    existing.setStatus(booking.getStatus());
                    existing.setUser(booking.getUser());
                    existing.setRoom(booking.getRoom());
                    return bookingRepository.save(existing);
                })
                .orElseThrow(() -> new RuntimeException("Booking not found with id: " + id));
    }

    @Override
    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }

    @Override
    public boolean isOverlappingBooking(Long roomId, LocalDateTime checkIn, LocalDateTime checkOut) {
        List<Booking> bookings = bookingRepository.findByRoom_Id(roomId);

        for (Booking b : bookings) {
            boolean overlap = !(checkOut.isBefore(b.getCheckIn()) || checkIn.isAfter(b.getCheckOut()));
            if (overlap) {
                return true;
            }
        }
        return false;
    }

    public Booking save(Booking booking) {
        return bookingRepository.save(booking);
    }


    @Override
    public List<Booking> findByUsername(String username) {
        return bookingRepository.findByUserUsername(username);
    }

}
