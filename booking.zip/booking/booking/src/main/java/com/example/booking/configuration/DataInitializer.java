package com.example.booking.configuration;

import com.example.booking.entity.Role;
import com.example.booking.entity.User;
import com.example.booking.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Fix: So sánh đúng username
        if (userRepository.findByUsername("admin").orElse(null) == null) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("123456")); // 🔒 mã hóa mật khẩu
            // Role adminRole = new Role("ADMIN"); // Assuming Role has a constructor that accepts a name
            // admin.setRole(adminRole); // Assuming User has a setter method for Role
            admin.setFullName("Administrator");
            admin.setEmail("admin@example.com");
            admin.setPhone("000000000");

            userRepository.save(admin);
            System.out.println("✅ Admin user created: admin / 123456");
        }
    }
}
