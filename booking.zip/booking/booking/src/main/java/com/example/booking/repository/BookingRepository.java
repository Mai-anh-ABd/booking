package com.example.booking.repository;

import com.example.booking.entity.Booking;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    // Có thể thêm custom query nếu cần, ví dụ:
    List<Booking> findByUserId(Long userId);
    List<Booking> findByRoom_Id(Long roomId);
    List<Booking> findByUserUsername(String username);

}
