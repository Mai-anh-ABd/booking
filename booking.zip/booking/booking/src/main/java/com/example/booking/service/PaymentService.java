package com.example.booking.service;

import com.example.booking.entity.Booking;
import com.example.booking.entity.Payment;

import java.util.List;
import java.util.Optional;

public interface PaymentService {
    List<Payment> getAllPayments();
    Optional<Payment> getPaymentById(Long id);
    Payment createPayment(Payment payment);
    void deletePayment(Long id);
    Payment findByBooking(Booking booking);
}
